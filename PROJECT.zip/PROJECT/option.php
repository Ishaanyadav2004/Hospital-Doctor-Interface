<?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

if($con->connect_error){
  die("Connection failed".mysqli_connect_error());
}//else{
//   echo "connection successfull";
// }
$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$status=$row['status'];
if($status=="accept"){
    header("Location: http://127.0.0.1:5501/acceptedbydoctor.html");
}
else if($status=="decline"){
    header("Location: http://127.0.0.1:5501/declinedbydoctor.html");
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=4, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <div class="header"></div>
    <input type="checkbox" id="openSidebarMenu">
    <label for="openSidebarMenu" class="sidebarIconToggle">
        <div class="spinner top"></div>
        <div class="spinner middle"></div>
        <div class="spinner bottom"></div>
    </label>
    <div id="sidebarMenu">
        <ul class="menu">
            <li><a href="index.html">Profile</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="#">Help</a></li>
        </ul>
    </div>

    <div class="main"><br>
    <a class="a2" href="http://localhost/project/accepted.php">
    <div class="Accept">ACCEPT</div>
</a>
<a class="a2" href="http://localhost/project/declined.php">
    <div class="Decline">DECLINE</div>
</a>
<?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);

$row=mysqli_fetch_assoc($result);
echo $row['date'];
echo "<br>";
// $row=mysqli_fetch_assoc($result);
echo $row['time'];
?>
</div>

    <div class="content" id="time2" class="time2"></div>
</body>