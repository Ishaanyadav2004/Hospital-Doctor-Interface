<?php
if(isset($_POST['full_name'])){
$server="localhost";
$username="root";
$password="";
$database="PROJECT";

$con=mysqli_connect($server,$username,$password,$database);

if($con->connect_error){
    die("Connection failed".mysqli_connect_error());
}

$full_name=$_POST['full_name'];
$date=$_POST['date'];
$time=$_POST['time'];

$sql="INSERT INTO `PROJECT`.`booking` (`full_name`,`date`,`time`,`status`) VALUES('$full_name','$date','$time','pending')";
$result=mysqli_query($con,$sql);

if($con->query($sql)==true){
    echo '<script type="text/javascript">';
    echo 'alert("your request is pending")';
    echo 'window.location.href="book_main_page.php';
    echo '</script>';
}
else{
    echo "ERROR: $sql <br> $conn->error";
}
$con->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=4, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <div class="header"></div>
    <input type="checkbox" id="openSidebarMenu">
    <label for="openSidebarMenu" class="sidebarIconToggle">
        <div class="spinner top"></div>
        <div class="spinner middle"></div>
        <div class="spinner bottom"></div>
    </label>
    <div id="sidebarMenu">
        <ul class="menu">
            <li><a href="hospital profile.html">Profile</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="#">Book Doctor</a></li>
            <li><a href="#">Help</a></li>
        </ul>
    </div>
    <section class="book" id="book">
       
        <div class="row">
            <form action="booking.php" method="POST">
                <h1>Book Doctor</h1><br>
                <input type="text" placeholder="Full Name" name="full_name"><br>
                <input type="number" placeholder="Your Number" name="id_no"><br>
                <input type="date" name="date"><br>
                <input type="time" name="time"><br>
                <input type="submit" value="Book Now" name="book"><br>
            </form>
        </div>

    </section>
</body>