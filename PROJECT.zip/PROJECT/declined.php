<?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

if($con->connect_error){
    die("Connection failed".mysqli_connect_error());
}
// else{
//     echo "connection was successfull";
// }
$sql="UPDATE `booking` SET `status`='decline' WHERE `full_name`='yuva'";
$result=mysqli_query($con,$sql);
// echo "<br>";
// echo "UPDATED AS DECLINED";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=4, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .Ishrequest1{
            font-size:40px;
    font-family: sans-serif;
        }
    </style>
</head>
<body>
    <div class="header"></div>
    <input type="checkbox" id="openSidebarMenu">
    <label for="openSidebarMenu" class="sidebarIconToggle">
        <div class="spinner top"></div>
        <div class="spinner middle"></div>
        <div class="spinner bottom"></div>
    </label>
    <div id="sidebarMenu">
        <ul class="menu">
            <li><a href="index.html">Profile</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="#">Help</a></li>
        </ul>
    </div>
    <div class="main"><br>
    <div class="Ishrequest1">
You have declined the request</div>
</div>
    
</body>