<?php
if(isset($_POST['fullName'])){
$server="localhost";
$username="root";
$password="";
$database="edi";
$con=mysqli_connect($server,$username,$password,$database);

if($con->connect_error){
  die("Connection failed".mysqli_connect_error());
}else{
  echo "connection successfull";
}

$fullname=$_POST['fullName'];
$username=$_POST['username'];
$email=$_POST['email'];
$phone_no=$_POST['phoneNumber'];
$password=$_POST['password'];
$gender=$_POST['gender'];



$sql="INSERT INTO `edi`.`register` (`full_name`,`username`,`email`,`phone_no`,`password`,`gender`) VALUES ('$fullname','$username','$email','$phone_no','$password','$gender')";
$result=mysqli_query($con,$sql);
header("Location: http://127.0.0.1:5501/registrationpending.html");
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Responsive Registration Form</title>
    <meta name="viewport" content="width=device-width,
      initial-scale=1.0"/>
    <link rel="stylesheet" href="registration.css" />
  </head>
  <body>
    <div class="container">
      <h1 class="form-title">Registration For Doctors</h1>
      <form action="registration.php" method='POST'>
        <div class="main-user-info">
          <div class="user-input-box">
            <label for="fullName">Full Name</label>
            <input type="text"
                    id="fullName"
                    name="fullName"
                    placeholder="Enter Full Name"/>
          </div>
          <div class="user-input-box">
            <label for="username">Username</label>
            <input type="text"
                    id="username"
                    name="username"
                    placeholder="Enter Username"/>
          </div>
          <div class="user-input-box">
            <label for="email">Email</label>
            <input type="email"
                    id="email"
                    name="email"
                    placeholder="Enter Email"/>
          </div>
          <div class="user-input-box">
            <label for="phoneNumber">Phone Number</label>
            <input type="text"
                    id="phoneNumber"
                    name="phoneNumber"
                    placeholder="Enter Phone Number"/>
          </div>
          <div class="user-input-box">
            <label for="password">Password</label>
            <input type="password"
                    id="password"
                    name="password"
                    placeholder="Enter Password"/>
          </div>
          <div class="user-input-box">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    placeholder="Confirm Password"/>
          </div>
        </div>
        <div class="gender-details-box">
          <span class="gender-title">Gender</span>
          <div class="gender-category">
            <input type="radio" name="gender" id="male">
            <label for="male">Male</label>
            <input type="radio" name="gender" id="female">
            <label for="female">Female</label>
            <input type="radio" name="gender" id="other">
            <label for="other">Other</label>
          </div>
        </div>
        <div class="form-submit-btn">
          <input type="submit" value="Register">
        </div>
      </form>
    </div>
  </body>
</html>