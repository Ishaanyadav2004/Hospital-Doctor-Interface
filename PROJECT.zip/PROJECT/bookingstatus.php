<?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

if($con->connect_error){
  die("Connection failed".mysqli_connect_error());
}
$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$status=$row['status'];
if($status=="pending"){
    echo "your appointment is currently pending";
}
else{
    echo "your appointment has been ".$status;
}
?>