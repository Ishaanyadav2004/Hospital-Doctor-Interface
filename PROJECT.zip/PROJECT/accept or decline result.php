<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=4, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <div class="header"></div>
    <input type="checkbox" id="openSidebarMenu">
    <label for="openSidebarMenu" class="sidebarIconToggle">
        <div class="spinner top"></div>
        <div class="spinner middle"></div>
        <div class="spinner bottom"></div>
    </label>
    <div id="sidebarMenu">
        <ul class="menu">
            <li><a href="index.html">Profile</a></li>
            <li><a href="book main page.html">Book Doctors</a></li>
            <li><a href="about.html">About Us</a></li>
            <li><a href="#">Help</a></li>
        </ul>
    </div>
    <div class="main"></div><br>
    <div class="doctor">
        Your Request has been <?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);

$row=mysqli_fetch_assoc($result);
echo $row['status'];
?> on <br>
        <?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);

$row=mysqli_fetch_assoc($result);
echo $row['date'];
?><br>
        <?php
$server="localhost";
$username="root";
$password="";
$database="project";
$con=mysqli_connect($server,$username,$password,$database);

$sql="SELECT * FROM `booking`";
$result=mysqli_query($con,$sql);

$row=mysqli_fetch_assoc($result);
echo $row['time'];
?>
    <div class="content"></div>
</body>
